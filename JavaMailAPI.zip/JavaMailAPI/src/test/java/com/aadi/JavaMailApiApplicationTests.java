package com.aadi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaMailApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
