package com.aadi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaMailApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaMailApiApplication.class, args);
	}

}
