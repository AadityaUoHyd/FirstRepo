package com.aadi.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;
import com.aadi.util.EmailUtil;

@Component
public class ConsoleRunner implements CommandLineRunner {
	
	@Autowired
	private EmailUtil util;
	
	@Override
	public void run(String... args) throws Exception
	{
		//ClassPathResource file=new ClassPathResource("abc.txt");
		FileSystemResource file=new FileSystemResource("C:\\Users\\Aaditya Raj\\Pictures\\Kiara.jpg");
		boolean flag=util.send("aadityaraj.raj402@gmail.com", "Kiara Pic", "Hello Aadi, How are you?", file);
		if(flag) System.out.println("SENT");
		else System.out.println("CHECK PROBLEMS");
	}
}